# 论文修订交付包

先看 docs/mcp-thesis-editorial-revision.md。

PDF：docs/latex-preview/main.pdf；Word：docs/thesis-draft.docx；Markdown：docs/mcp-thesis-draft.md。

LaTeX 编译与内容重建说明见 docs/latex-preview/README.md。项目根目录布局已保留，源码中的图片路径按项目根目录解析。

包含本轮修订与复核材料，不包含模型权重、runtime 或全部原始数据/预测；复现分析请在原项目中运行。公开对照论文全文未收入本包。
